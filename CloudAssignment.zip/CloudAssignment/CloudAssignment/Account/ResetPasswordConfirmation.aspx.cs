﻿using System.Web.UI;

namespace CloudAssignment.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}